package pkg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.MappedByteBuffer;
import java.util.Arrays;
import java.util.Formatter;

import javax.websocket.EndpointConfig;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.PongMessage;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@ServerEndpoint("/websocket/a")
public class MyWebSocket {
	static byte[] byte_string;
	static {

		URL path2 = MyWebSocket.class.getProtectionDomain().getCodeSource()
				.getLocation();
		File file = new File(new File(path2.getPath()).getParentFile()
				.getParentFile().getParentFile().getParentFile().toString(),
				"happyk_st.js.lzo");// "happyk_st.js.lzo");
		// System.out.println(file.toString());
		FileChannel channel = null;
		try {
			channel = new RandomAccessFile(file, "r").getChannel();
			// if (session.isOpen()) {
			MappedByteBuffer buffer = channel
					.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
					.load().force();
			byte_string = new byte[buffer.limit()];
			buffer.get(byte_string);

			// echoBinaryMessage(session, ByteBuffer.wrap(bt), false);
			// System.out.println(Arrays.toString(bt));

			// }
			// channel.close();
			// session.close();
		} catch (FileNotFoundException e) {
			System.out.println("file not found");
		} catch (IOException e) {
			/*
			 * try { //session.close(); System.out.println("IOEception"); }
			 * catch (IOException e1) { // Ignore }
			 */
		} finally {
			if (channel != null) {
				try {
					System.out.println("close");
					channel.close();
					// session.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}
	}

	@OnMessage
	public void echoBinaryMessage(Session session, ByteBuffer bb, boolean last) {
			if (session.isOpen()) {
				try {
					session.getBasicRemote().sendBinary(ByteBuffer.wrap(byte_string), last);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// session.getBasicRemote().sendText("123", last);
			} else {
				System.out.println("session is not open");
			}

	}

	@OnMessage
	public void echoTextMessage(Session session, String msg, boolean last) {
		System.out.println("txt");
		try {
			if (session.isOpen()) {
				session.getBasicRemote().sendText(msg, last);
			}
		} catch (IOException e) {
			try {
				session.close();
			} catch (IOException e1) {
				// Ignore
			}
		}
	}

	/**
	 * Process a received pong. This is a NO-OP.
	 *
	 * @param pm
	 *            Ignored.
	 */
	@OnMessage
	public void echoPongMessage(PongMessage pm) {
		System.out.println("pong");
	}
}
