

package pkg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.MappedByteBuffer;
import java.util.Arrays;
import java.util.Formatter;

import javax.websocket.EndpointConfig;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.PongMessage;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@ServerEndpoint("/websocket/b")
public class MyFromClientSocket {
	/*MessageDigest md;
	@OnOpen
	public void openSend(Session session, EndpointConfig conf){
    	if (session.isOpen()) {
    		System.out.println("opened");
    	}else{
    		System.out.println("session is not open");
    	}
    	try {
			md = MessageDigest.getInstance("SHA1");
			System.out.println("init");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int save = 0;
	public int size = 0;
    */
    @OnMessage
    public void echoBinaryMessage(Session session, ByteBuffer bb,
            boolean last) {

    	/*if(save >= 1){
        	URL path2 = MyWebSocket.class.getProtectionDomain().getCodeSource().getLocation();

        	File file = new File(new File(path2.getPath()).getParentFile().getParentFile().getParentFile().getParentFile().toString(), "happyk_st.js.lzo");


        	try {
            	//System.out.println(bb.array().length == bb.remaining());
            	FileOutputStream out = new FileOutputStream(file, save != 1);
            	//System.out.println(Arrays.toString(bb.array()));
            	byte[] btArray = new byte[bb.remaining()];
            	bb.get(btArray);
            	System.out.println(btArray.length);
                md.update(btArray);
                if(btArray.length == 3961){
                	byte[] output = md.digest();
                	String hexString = "";
                    StringBuilder sb = new StringBuilder(output.length * 2);  
                    
                    Formatter formatter = new Formatter(sb);  
                    for (byte b : output) {  
                        formatter.format("%02x", b);  
                    }  
                  
                    System.out.println(sb.toString());
                }
            	out.write(btArray);

	        	out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
	        	save++;
			}
        	return;
    	}else{
    		System.out.println("not printed");
    	}
    	save = 1;*/

    	URL path2 = MyWebSocket.class.getProtectionDomain().getCodeSource().getLocation();
    	File file = new File(new File(path2.getPath()).getParentFile().getParentFile().getParentFile().getParentFile().toString(), "output.lzo");//"happyk_st.js.lzo");
    	FileChannel channel = null; // needs to be closed outside of try block.
        try {
        	channel = new RandomAccessFile(file, "rw").getChannel();
            	MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, bb.remaining()).load().force();
            	buffer.put(bb);
            	if (session.isOpen()) {
            		session.getBasicRemote().sendText("recieved", last);
            	}else{
            		System.out.println("session is not open");
            	}
        } catch (FileNotFoundException e){
        	System.out.println("file not found");
        } catch (IOException e) {
            try {
                session.close();
                System.out.println("IOEception");
            } catch (IOException e1) {
                // Ignore
            }
        }finally{
        	if(channel != null){
        		try {
					channel.close();
					session.close();
				} catch (IOException e) {
					//ignore
				}
        	}
        }
    }
 
    @OnMessage
    public void echoTextMessage(Session session, String msg, boolean last) {
    	System.out.println("txt");
        try {
            if (session.isOpen()) {
                session.getBasicRemote().sendText(msg, last);
            }
        } catch (IOException e) {
            try {
                session.close();
            } catch (IOException e1) {
                // Ignore
            }
        }
    }
}


